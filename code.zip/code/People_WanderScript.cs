﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.AI;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace PolyPerfect
{
    public class People_WanderScript : Common_WanderScript { }
}