﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinNum : MonoBehaviour
{
    public int Num;
    public GameObject theobj;
    void Start()
    {
        theobj = gameObject;
    }

    void Update()
    {
        
    }
}
