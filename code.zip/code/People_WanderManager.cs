﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PolyPerfect
{
    public class People_WanderManager : Common_WanderManager { }
}