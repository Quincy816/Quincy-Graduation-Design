﻿
namespace PolyPerfect
{
    public class People_SurfaceRotation : Common_SurfaceRotation { }

}