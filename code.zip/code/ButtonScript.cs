﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonScript : MonoBehaviour
{
	public void LoadStage1()  {
		SceneManager.LoadScene ("Testscene1");
	}
	public void LoadStage2()  {
		SceneManager.LoadScene ("Testscene2");
	}
	public void LoadStage3()  {
		SceneManager.LoadScene ("Testscene3");
	}
	public void LoadStage4()  {
		SceneManager.LoadScene ("Testscene4");
	}
	public void LoadStage5()  {
		SceneManager.LoadScene ("Testscene5");
	}
	public void LoadStage6()  {
		SceneManager.LoadScene ("Testscene6");
	}
}