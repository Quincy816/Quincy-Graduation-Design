﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PolyPerfect
{
    public class People_AIStats : AIStats { }
}

